# How to edit styles
Do not edit css files directly. Always make your changes in the scss files and then compile them to css.